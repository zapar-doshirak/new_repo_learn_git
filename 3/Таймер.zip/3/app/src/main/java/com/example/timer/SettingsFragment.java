package com.example.timer;

import android.preference.PreferenceFragment;

public class SettingsFragment extends PreferenceFragment {
}
